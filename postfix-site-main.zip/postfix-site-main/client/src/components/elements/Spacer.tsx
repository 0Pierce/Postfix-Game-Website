import React from 'react'
import '/src/styles/Spacer.css'


export default function Spacer() {
  return (
    <>
    <div className="spacerBody">
        
    </div>
    
    </>
  )
}
